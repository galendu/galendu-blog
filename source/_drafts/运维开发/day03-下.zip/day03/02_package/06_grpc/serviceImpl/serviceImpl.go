package serviceImpl

import (
	"context"
	"day03/02_package/06_grpc/pb"
	"fmt"
)
//pb.UnimplementedMessageSenderServer结构体实现了MessageSenderServer接口
//通过嵌套的方式，我们自己定义的结构体也实现了MessageSenderServer接口
//实现后，我们就可以重写proto中定义的rpc方法
//通过这种方式在rpc方法中写入我们的业务逻辑
type MessageSenderServerImpl struct {
	*pb.UnimplementedMessageSenderServer
}

func(MessageSenderServerImpl) Send(ctx context.Context, request *pb.MessageRequest) (*pb.MessageResponse, error) {
	//打印请求参数
	fmt.Println("receive message:", request.Saysomething)
	//处理响应
	resp := &pb.MessageResponse{
		ResponseSomething: "this is grpc server, roger that",
	}
	return resp, nil
}