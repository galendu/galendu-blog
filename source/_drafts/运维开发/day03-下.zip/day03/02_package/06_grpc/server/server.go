package main

import (
	"day03/02_package/06_grpc/pb"
	"day03/02_package/06_grpc/serviceImpl"
	"google.golang.org/grpc"
	"net"
)

func main() {
	//new一个grpc服务端
	srv := grpc.NewServer()
	//注册grpc服务
	pb.RegisterMessageSenderServer(srv, serviceImpl.MessageSenderServerImpl{})
	//启动服务
	listener, err := net.Listen("tcp", ":8002")
	if err != nil {
		panic(err)
	}
	if err := srv.Serve(listener); err != nil {
		panic(err)
	}
}
