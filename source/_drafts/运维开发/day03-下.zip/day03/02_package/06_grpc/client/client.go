package main

import (
	"context"
	"day03/02_package/06_grpc/pb"
	"fmt"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

func main() {
	//建立grpc连接
	conn, err := grpc.Dial("127.0.0.1:8002", grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		panic(err)
	}
	defer conn.Close()
	//new一个grpc服务的client
	client := pb.NewMessageSenderClient(conn)
	resp, err := client.Send(context.Background(), &pb.MessageRequest{
		Saysomething: "中文",
	})
	if err != nil {
		panic(err)
	}
	fmt.Println("receive message:", resp.ResponseSomething)
}