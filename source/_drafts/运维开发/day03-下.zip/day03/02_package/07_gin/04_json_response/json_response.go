package main

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

func ListHandler(c *gin.Context) {
	//常规业务返回
	c.JSON(http.StatusOK, gin.H{
		//为什么会有业务状态码呢，因为一般只要正常返回（网络正常），那么http状态码都是200
		//使用业务状态码区分业务的异常情况
		//入参错误：90400   业务逻辑处理错误：90500  没有权限：90403  ...
		"code": 0,  //业务状态码，正常是0，异常包括90400 90500 90403
		"msg": "获取列表成功",  //正常或异常的响应信息,如果是异常，就是err信息
		"data": nil, //返回的数据，对于修改操作，一般都是nil，获取操作，都是对应的数据
	})
}

func main() {
	r := gin.Default()
	r.GET("/list", ListHandler)
	r.Run(":8000")
}
