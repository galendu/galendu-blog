package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
)

//GET请求的param处理
func GetBookHandler(c *gin.Context) {
	bookId := c.Param("id")
	c.String(http.StatusOK, fmt.Sprintf("成功获取书籍信息:%s", bookId))
}

func GetUserHandler(c *gin.Context) {
	//通过query方法获取url参数
	userId := c.Query("id")
	c.String(http.StatusOK, fmt.Sprintf("成功获取用户信息:%s", userId))
}

func main() {
	r := gin.Default()
	r.GET("/user", GetUserHandler)  // http://xxx/user?id=1   推荐
	r.GET("/book/:id", GetBookHandler)  // http://xxx/book/1   不推荐
	r.Run(":8000")
}