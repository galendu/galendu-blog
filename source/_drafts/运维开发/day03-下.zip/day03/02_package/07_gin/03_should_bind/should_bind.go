package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
)

type UserInfo struct {
	//json的tag用于接收application/json的参数，POST、PUT、DELETE。。
	//form的tag用于接收get请求的参数
	Username string `json:"username" form:"username" binding:"required"`
	Password string `json:"password" form:"password" binding:"required"`
}

func loginHandler(c *gin.Context) {
	params := &UserInfo{}
	err := c.ShouldBind(params)
	if err != nil {
		c.String(http.StatusBadRequest, err.Error())
		return //报错后直接返回出去，不在执行后面的代码
	}

	c.String(http.StatusOK, fmt.Sprintf("账号：%s, 密码：%s", params.Username, params.Password))
}

func main() {
	r := gin.Default()
	r.POST("/login", loginHandler)
	r.GET("/login", loginHandler)
	r.Run(":8000")
}
