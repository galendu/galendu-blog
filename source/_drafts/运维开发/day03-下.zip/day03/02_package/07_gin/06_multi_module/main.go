package main

import (
	"day03/02_package/07_gin/06_multi_module/routers"
	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	routers.LoadUsers(r)
	routers.LoadBooks(r)
	r.Run(":8000")
}
