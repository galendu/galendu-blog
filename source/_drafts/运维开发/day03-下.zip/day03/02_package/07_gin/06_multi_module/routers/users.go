package routers

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

func LoadUsers(r *gin.Engine) {
	r.GET("/user", GetUserHandler)
}

func GetUserHandler(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "user router",
		"data": nil,
	})
}