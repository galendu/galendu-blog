package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
)

func helloHandler(c *gin.Context) {
	//响应内容
	c.String(http.StatusOK, "hello world!")
}

func main() {
	//gin版本
	fmt.Println(gin.Version)

	//初始化gin实例
	r := gin.Default()
	//注册路由及handler
	r.GET("/hello", helloHandler)
	//启动server端
	r.Run(":8000")
}
