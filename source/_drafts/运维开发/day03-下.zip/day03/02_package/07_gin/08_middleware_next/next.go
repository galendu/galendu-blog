package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
)

//多个中间件顺序的安排
//场景1：log  recovery  没有顺序关系
//场景2：登录  权限校验   权限校验需要用户信息, 用户信息从登录来，所以登录在前，权限校验在后

func Middleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		fmt.Println("中间件-开始")
		c.Next()  //会执行业务handler
		fmt.Println("中间件-结束")
	}
}

func Log() gin.HandlerFunc {
	return func(c *gin.Context) {
		fmt.Println("log start")
		c.Next()
		fmt.Println("log end")
	}
}

func requestId() gin.HandlerFunc {
	return func(c *gin.Context) {
		fmt.Println("requestId start")
		c.Next()
		fmt.Println("requestId end")
	}
}

func main() {
	r := gin.Default()
	r.Use(Middleware(), Log(), requestId())
	r.GET("/hello", func(c *gin.Context) {
		fmt.Println("我是业务handler")
		c.JSON(http.StatusOK, gin.H{
			"code": 0,
			"msg": "success",
			"data": nil,
		})
	})
	r.Run(":8000")
}
