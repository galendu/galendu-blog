package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
)

//gin中间件的使用
//定义两个中间件
//返回一个gin.HandlerFunc的函数，在函数内去定义任意的操作
//这个函数和业务handler是相同的函数类型，所以可以放到同一个handler的链表中
//注册好后，会有限执行中间件，再执行业务handler
func Middleware1() gin.HandlerFunc {
	return func(c *gin.Context) {
		fmt.Println("我是一个全局中间件")
	}
}

func Middleware2() gin.HandlerFunc {
	return func(c *gin.Context) {
		fmt.Println("我是一个局部中间件")
	}
}

func main() {
	r := gin.Default()
	//全局中间件注册方式,写在路由注册的前面，那么use中间件后面的路由全部都会生效
	r.Use(Middleware1())
	r.GET("/index", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"code": 0,
			"msg": "index router",
			"data": nil,
		})
	})
	//局部注册中间件
	r.GET("/home", Middleware2(), func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"code": 0,
			"msg": "home router",
			"data": nil,
		})
	})
	r.Run(":8000")
}
