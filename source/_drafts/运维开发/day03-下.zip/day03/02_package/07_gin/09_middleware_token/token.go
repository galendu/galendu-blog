package main

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

//token校验中间件

func AuthMiddle() gin.HandlerFunc {
	return func(c *gin.Context) {
		//获取token
		token := c.GetHeader("token")
		//校验token
		//-token为空
		if len(token) == 0 {
			c.JSON(http.StatusOK, gin.H{
				"code": 90403,
				"msg": "no login",
				"data": nil,
			})
			//跳出中间件和业务handler的链表，后面的都不执行了
			c.Abort()
		}
		c.Next()
	}
}

func main () {
	r := gin.Default()
	r.Use(AuthMiddle())
	r.GET("/index", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"code": 0,
			"msg": "index router",
			"data": nil,
		})
	})
	r.Run(":8000")
}
