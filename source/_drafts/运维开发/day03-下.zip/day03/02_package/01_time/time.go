package main

import (
	"fmt"
	"time"
)

func main() {
	//time包的学习
	//时间对象，获取当前时间的对象
	now := time.Now()
	fmt.Println(now)
	//常用场景:数据库时间
	//created_at:  time.Now().Local()
	//updated_at:  time.Now().Local()
	now1 := time.Now().Local()
	fmt.Println(now1)
	//把时间对象转成格式化时间（字符串）
	//年月日时分秒格式必须按照 2006 01 02 15 04 05
	fortmatTime := now.Format("2006-01-02 15:04:05")
	fortmatTime1 := now.Format("2006-01-02 15:04:05.9999999")
	fmt.Println(fortmatTime, fortmatTime1)
	//获取时间戳，从1970年01月01日00时00分00秒到当前的总秒数或总毫秒数
	//秒时间戳
	fmt.Println(now.Unix())
	//毫秒时间戳
	fmt.Println(now.UnixMilli())

	//格式化时间转成时间对象
	loc, _ := time.LoadLocation("Asia/Shanghai")
	timeObj, _ := time.ParseInLocation("2006-01-02 15:04:05", fortmatTime, loc)
	fmt.Printf("%T %v\n", timeObj, timeObj)

	//获取时间对象的年月日时分秒
	year := now.Year()
	month := now.Month()
	day := now.Day()
	hour := now.Hour()
	minute := now.Minute()
	second := now.Second()
	fmt.Println(year, month, day, hour, minute, second)
	//02表示宽度，如果整数不够2位则在前面补上0
	fmt.Printf("%d-%02d-%02d %02d:%02d:%02d\n", year, month, day, hour, minute, second)

	//时间戳和时间对象的转换
	timeObj2 := time.Unix(now.Unix(), 0)
	timeObj3 := time.UnixMilli(now.UnixMilli())
	fmt.Println(timeObj2, timeObj3)

	//时间间隔 time.Duration
	//time.Sleep(5 * time.Second)

	//时间计算
	//一分钟后的时间对象: 当前时间+1分钟后的时间对象
	timeObj4 := now.Add(1 * time.Minute)
	fmt.Println(timeObj4)
	//一分钟前
	timeObj5 := now.Add(-1 * time.Minute)
	fmt.Println(timeObj5)

	//两个时间对象的差值
	duration := now.Sub(timeObj5)
	fmt.Println(duration)

	//duration转秒和毫秒
	fmt.Println(duration.Seconds(), duration.Milliseconds())
}