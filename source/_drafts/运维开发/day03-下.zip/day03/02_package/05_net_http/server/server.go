package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

//http.ResponseWriter用于响应数据
//http.Request用于获取请求信息
//定义传入参数body中 {"name":"root"}
func dealPostReqHandler(w http.ResponseWriter, r *http.Request) {
	//获取请求信息
	data, _ := ioutil.ReadAll(r.Body)
	var param = new(struct{
		Name string `json:"name"`
	})
	json.Unmarshal(data, param)  //反序列化的地方
	//业务逻辑处理
	fmt.Println("接收到的参数是", param.Name)
	//响应内容
	//状态码
	w.WriteHeader(http.StatusOK)
	//响应体1
	//b, _ := json.Marshal(param) //序列化的地方
	//w.Write(b)
	w.Write([]byte("接收到的参数是"+ param.Name))
	//响应体2
	//json.NewEncoder(w).Encode("接收到的参数是"+ param.Name)
}

// http://localhost:8005/req/get?name=root
func dealGetReqHandler(w http.ResponseWriter, r *http.Request) {
	//获取请求参数
	query := r.URL.Query()
	//第一种方式
	if len(query["name"]) > 0 {
		name := query["name"][0]
		fmt.Println("通过map获取:", name)
	}
	//第二种方式
	name := query.Get("name")
	fmt.Println("通过get函数获取:", name)
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("接收到的参数是"+ name))
}


func main() {
	//定义两个接口，以及接口对应的handler，也就是处理方法
	http.HandleFunc("/req/post", dealPostReqHandler)
	http.HandleFunc("/req/get", dealGetReqHandler)

	//监听端口并启动server端
	http.ListenAndServe(":8005", nil)
}