package main

import (
	"flag"
	"fmt"
	"time"
)

func main() {
	//flag包的学习
	//flag包常用语脚本或程序启动时，命令行入参的控制

	//定义变量  启动exe --name=zhangsan
	var (
		name string
		age int
		married bool
		delay time.Duration
	)
	//定义命令行参数
	/*
		参数1：绑定到的变量
		参数2：参数名
		参数3：默认值
		参数4：-h中的注释
	*/
	flag.StringVar(&name, "name", "张三", "姓名")
	flag.IntVar(&age, "age", 18, "年龄")
	flag.BoolVar(&married, "married", false, "婚否")
	flag.DurationVar(&delay, "delay", 0, "迟到")
	//解析参数
	flag.Parse()
	//使用参数
	fmt.Println(name, age, married, delay)
	//xxxx

	//生成脚本
	//go build flag.go

	//传入非参数的其他内容
	fmt.Println(flag.Args())
	//非参数的其他内容的长度
	fmt.Println(flag.NArg())
	//传入的参数的长度
	fmt.Println(flag.NFlag())
}
