package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
)

func main() {
	apiUrl := "http://localhost:8005/req/post"
	//设置请求头以及body
	contentType := "application/json"
	data := `{"name":"wangwu"}` //序列化的地方,结构体转成字符串才能发送
	resp, _ := http.Post(apiUrl, contentType, strings.NewReader(data))
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body) //反序列化的地方,响应体绑定到结构体
	fmt.Println("获取到的响应数据为 ", string(body))
}
