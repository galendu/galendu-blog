package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
)

func main() {
	//发起get请求
	//定义url
	apiUrl := "http://localhost:8005/req/get"
	//apiUrl := "http://localhost:8005/req/get?name=zhangsan"
	//设置请求参数
	data := url.Values{}
	data.Set("name", "lisi")
	//拼接url
	u, _ := url.ParseRequestURI(apiUrl)
	u.RawQuery = data.Encode()
	fmt.Println("请求完成路径为:", u.String())

	//发起请求
	resp, _ := http.Get(u.String())
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	fmt.Println("获取的响应数据为", string(body))
}
