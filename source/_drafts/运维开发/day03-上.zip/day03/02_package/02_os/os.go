package main

import (
	"fmt"
	"os"
)

//文件操作：操作的是当前运行环境上的文件，会有分布式问题
//一般情况下，文件操作后，文件会存储在一个集中的地方，而不是在运行环境上（机器或容器）,比如对象存储

func main() {
	//os包的学习
	//获取当前目录 pwd
	fmt.Println(os.Getwd())
	//获取环境变量
	fmt.Println(os.Getenv("GOPATH"))
	//进入指定目录 cd
	//os.Chdir("../")
	//fmt.Println(os.Getwd())
	//创建目录
	//os.Mkdir("go_demo", 0777)
	//删除文件或目录
	//os.Remove("go_demo")
	//重命名文件或目录
	//os.Rename("go_demo", "new_go_demo")
	//新建文件
	//os.Create("file.txt")

	//打开文件并写入内容
	/*
		O_RDONLY 打开只读文件
		O_WRONLY 打开只写文件
		O_RDWR   打开读写文件
		O_APPEND 写入文件时追加到文件末尾
		O_CREATE 文件不存在时自动创建
		O_TRUNC  写入文件时覆盖原来内容
	*/
	file, _ := os.OpenFile("file.txt", os.O_RDWR|os.O_APPEND, 0666)
	defer file.Close()
	file.WriteString("你好 golang")
}