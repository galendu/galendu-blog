package main

import (
	"fmt"
	"io/ioutil"
	"os"
	"strings"
)

func main() {
	//ioutil包的学习
	//读取文件中的所有数据
	fileName := "./file.txt"
	data, _ := ioutil.ReadFile(fileName)
	fmt.Println(string(data))
	//写入数据
	str := "hello world"
	ioutil.WriteFile(fileName, []byte(str), 0777)
	//读取所有数据,模拟数据放入reader类型中，再读取，从response中读取
	r := strings.NewReader(str)
	data2, _ := ioutil.ReadAll(r)
	fmt.Println(string(data2))

	//读取一个目录下面所有字内容，包括文件和目录，但是只有一层
	dir, _ := os.Getwd()
	info, _ := ioutil.ReadDir(dir)
	for _, val := range info {
		fmt.Println(val.Name())
	}
}
